# 提示词翻译文档

## 元信息
- 原文件位置: `src/lib/prompts/communication-analysis.ts`
- 变量名称: `SYSTEM_PROMPT`、`getCommunicationAnalysisPrompt`
- 功能模块: 沟通能力专项分析
- 调用场景: `analyze-communication` 接口收到 `transcript` 后调用，返回对沟通能力的评分、引用佐证、优势与改进项。

## 中文翻译

### 系统提示词 (SYSTEM_PROMPT)

```
你是分析面试逐字稿中沟通技巧的专家。你的任务是：
1. 分析逐字稿中展现的沟通技巧
2. 找出支持你分析结论的具体引用
3. 提供优势与待改进之处的详细拆解
```

### 用户提示词 (getCommunicationAnalysisPrompt)

```
分析以下面试逐字稿中展现的沟通技巧：

逐字稿：${transcript}

请以如下 JSON 格式提供你的分析：
{
  "communicationScore": number, // 基于标准沟通评分体系的 0-10 评分
  "overallFeedback": string,   // 对沟通技巧的 2-3 句总结
  "supportingQuotes": [        // 相关引用及其分析组成的数组
    {
      "quote": string,         // 逐字稿中的原话引用
      "analysis": string,      // 简要分析该引用体现了沟通技巧的哪些方面
      "type": string           // 取值为 "strength" 或 "improvement_area"
    }
  ],
  "strengths": [string],       // 所展现的沟通优势列表
  "improvementAreas": [string] // 可改进之处列表
}
```

## 关键参数
- `${transcript}` — 面试逐字稿文本

## 相关代码上下文
- 在 [analyze-communication/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/analyze-communication/route.ts#L26-L39) 中使用 `gpt-4o` + `response_format: { type: "json_object" }` 调用，解析后返回 `analysis`。

## 译注
- 该接口（`POST /api/analyze-communication`）在当前前端代码中未发现调用入口，可能为预留/未完成的功能 [待确认]。
- `strength` / `improvement_area` 为模型输出的枚举类型标记文本。