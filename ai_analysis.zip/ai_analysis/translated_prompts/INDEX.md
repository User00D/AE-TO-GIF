# 提示词翻译文档索引

本项目所有已识别的大模型提示词索引如下。

| 编号 | 提示词 / 变量 | 原文件位置 | 功能模块 | 翻译文档 |
|------|--------------|------------|----------|----------|
| 1 | `RETELL_AGENT_GENERAL_PROMPT` | `src/lib/constants.ts:1` | 语音面试 Agent（Retell AI） | [constants_retell_voice_agent_prompt_zh.md](./constants_retell_voice_agent_prompt_zh.md) |
| 2 | `SYSTEM_PROMPT` + `getInterviewAnalyticsPrompt` | `src/lib/prompts/analytics.ts` | 面试转录分析与评分 | [analytics_interview_analysis_prompt_zh.md](./analytics_interview_analysis_prompt_zh.md) |
| 3 | `SYSTEM_PROMPT` + `getCommunicationAnalysisPrompt` | `src/lib/prompts/communication-analysis.ts` | 沟通能力专项分析 | [communication-analysis_prompt_zh.md](./communication-analysis_prompt_zh.md) |
| 4 | `SYSTEM_PROMPT` + `createUserPrompt` | `src/lib/prompts/generate-insights.ts` | 面试洞察生成 | [generate-insights_prompt_zh.md](./generate-insights_prompt_zh.md) |
| 5 | `SYSTEM_PROMPT` + `generateQuestionsPrompt` | `src/lib/prompts/generate-questions.ts` | 自动生成面试问题与描述 | [generate-questions_prompt_zh.md](./generate-questions_prompt_zh.md) |

## 工具索引

| 编号 | 工具名称 | 类型 | 所在位置 | 说明 |
|------|---------|------|----------|------|
| 1 | `end_call_1` | `end_call` | `src/app/api/create-interviewer/route.ts:18-25` | 语音 Agent 结束通话工具 |

## 说明
- 提示词原始语言均为英文，本目录提供中文翻译（保留原始占位符）。
- 全部 GPT 调用采用 `gpt-4o` 模型，并通过 `response_format: { type: "json_object" }` 约束为 JSON 输出。
- 语音 Agent（Retell AI）底层亦为 `gpt-4o`，通过 `general_prompt` + 动态变量驱动。