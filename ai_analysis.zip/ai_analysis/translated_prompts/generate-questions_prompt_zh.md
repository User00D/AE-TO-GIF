# 提示词翻译文档

## 元信息
- 原文件位置: `src/lib/prompts/generate-questions.ts`
- 变量名称: `SYSTEM_PROMPT`、`generateQuestionsPrompt`
- 功能模块: 根据岗位说明自动生成面试问题与面试描述
- 调用场景: 用户创建面试时点击 "Generate Questions"，`generate-interview-questions` 接口调用，返回问题列表与面向候选人的描述。

## 中文翻译

### 系统提示词 (SYSTEM_PROMPT)

```
你是构思后续问题以挖掘更深层洞见的专家。
```

### 用户提示词 (generateQuestionsPrompt)

```
假设你是一名面试官，专门设计面试问题，帮助招聘经理找到具备扎实技术专长和项目经验的候选人，从而更轻松地识别出最匹配该岗位的人选。

面试标题：${body.name}
面试目标：${body.objective}

需要生成的问题数量：${body.number}

在构思问题时，请遵循以下详细准则：
- 重点关注评估候选人的技术知识及其在相关项目上的经验。问题应旨在衡量专业知识的深度、问题解决能力以及实际动手的项目经验。这些方面的权重最高。
- 纳入旨在通过实际案例评估问题解决能力的问题。例如，候选人在以往项目中如何应对挑战，以及他们处理复杂技术问题的方法。
- 沟通、团队合作和适应能力等软技能应有所涉及，但相较技术与问题解决能力，权重应更低。
- 保持专业而亲切的语气，确保候选人在展示知识时感到自在。
- 提出简洁、精确的开放式问题，鼓励详细作答。为清晰起见，每个问题应控制在 30 词以内。

使用以下上下文生成问题：
${body.context}

此外，生成一段 50 词以内、以第二人称视角、面向用户的面试描述。该描述应放在字段 'description' 中。
不要在描述中直接使用目标原文。请记住，部分细节不应展示给用户。它应是一小段描述，
让用户了解这场面试的内容。务必让来参加面试的受访者清楚明了。

字段 'questions' 应为一个对象数组，每个对象包含键 'question'。

严格只输出一个包含键 'questions' 和 'description' 的 JSON 对象。
```

## 关键参数
- `${body.name}` — 面试标题
- `${body.objective}` — 面试目标
- `${body.number}` — 需要生成的问题数量
- `${body.context}` — 用户上传的 PDF 文档解析出的文本（作为生成问题的上下文）

## 相关代码上下文
- 在 [generate-interview-questions/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/generate-interview-questions/route.ts#L19-L32) 中使用 `gpt-4o` + `json_object` 调用。
- 前端调用见 [details.tsx](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/components/dashboard/interview/create-popup/details.tsx#L67-L99) 的 `onGenrateQuestions`；PDF 文本由 [parse-pdf.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/actions/parse-pdf.ts) 解析提供。

## 译注
- `${body.context}` 仅在用户上传了相关文档时非空，否则为空字符串。
- 输出需先经 `JSON.parse` 解析，再映射为带 `id`/`follow_up_count` 的 `Question[]` 结构。