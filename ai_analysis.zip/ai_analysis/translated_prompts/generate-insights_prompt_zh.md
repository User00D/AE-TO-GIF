# 提示词翻译文档

## 元信息
- 原文件位置: `src/lib/prompts/generate-insights.ts`
- 变量名称: `SYSTEM_PROMPT`、`createUserPrompt`
- 功能模块: 面试洞察生成
- 调用场景: `generate-insights` 接口，汇总某场面试下所有通话摘要，生成 3 条用户反馈洞察并写回面试记录。

## 中文翻译

### 系统提示词 (SYSTEM_PROMPT)

```
你是从面试问答集中挖掘深层洞见的专家。
```

### 用户提示词 (createUserPrompt)

```
假设你是一名面试官，擅长从通话摘要中挖掘深层洞见。
使用下面的通话摘要列表和面试详情来生成洞见。

###
通话摘要：${callSummaries}

###
面试标题：${interviewName}
面试目标：${interviewObjective}
面试描述：${interviewDescription}

从通话摘要中给出 3 条突出用户反馈的洞见。只输出洞见本身。不要在洞见中包含用户名。
确保每条洞见不超过 25 词。

以 JSON 格式输出答案，键名为 "insights"，值为包含 3 条洞见的数组。
```

## 关键参数
- `${callSummaries}` — 所有通话摘要的拼接字符串（来自 `response.details.call_analysis.call_summary`）
- `${interviewName}` — 面试标题
- `${interviewObjective}` — 面试目标
- `${interviewDescription}` — 面试描述

## 相关代码上下文
- 在 [generate-insights/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/generate-insights/route.ts#L29-L58) 中使用 `gpt-4o` + `json_object` 调用，解析 `insights` 数组后经 `InterviewService.updateInterview` 持久化。

## 译注
- `call_summary` 由 Retell AI 提供（通话结束后的自动分析字段）。
- 当前前端没有直接调用该接口的入口，可能由外部/计划中的流程触发 [待确认]。