# FoloUp 大模型应用分析报告

## 1. 项目概述
- 项目名称: FoloUp
- 项目描述: 一个开源的、面向企业的 AI 语音面试平台。企业可基于任意岗位描述自动生成面试问题，通过分享链接让 AI 以自然对话方式对候选人进行语音面试，并自动生成评分与洞察。
- 主要功能:
  - 面试创建：从岗位说明（可选上传 PDF）自动生成定制面试问题
  - 一键分享：生成唯一面试链接，候选人秒级加入
  - AI 语音面试：由 AI 进行自然、对话式面试，并根据候选人回答自适应追问
  - 智能分析：对每个面试回答生成详细洞察与评分
  - 综合仪表盘：跟踪候选人表现与整体统计
- 技术栈: Next.js 16 (App Router) + TypeScript + React 18、Supabase（数据存储）、Clerk（认证）、Retell AI（语音通话托管）、OpenAI gpt-4o（问题生成与回答分析）、LangChain（PDF 解析）、Tailwind CSS + shadcn/ui + MUI。

## 2. 项目逻辑或数据流分析

项目同时使用了 **两类大模型能力**：
1. **OpenAI gpt-4o 直连调用** —— 用于"离线"的内容生成与文本分析（问题生成、逐字稿分析、沟通分析、洞察生成），均为单次请求-响应。
2. **Retell AI 语音 Agent** —— 用于"在线"的实时语音面试，底层仍是 gpt-4o，但交由 Retell 托管，形成多轮对话（Agent 循环）。

```mermaid
sequenceDiagram
    participant U as 招聘经理(企业用户)
    participant FE as Next.js 前端
    participant API as Next.js API Routes
    participant OAI as OpenAI gpt-4o
    participant RE as Retell AI
    participant SB as Supabase
    participant C as 候选人

    U->>FE: 填写面试名称/目标/上传PDF/设问题数
    FE->>API: POST /api/generate-interview-questions
    API->>OAI: chat.completions (generate-questions 提示词)
    OAI-->>API: JSON {questions[], description}
    API-->>FE: 返回问题与描述
    FE->>API: POST /api/create-interview
    API->>SB: 保存面试记录
    FE-->>U: 生成分享链接

    C->>FE: 打开面试链接，提交姓名/邮箱
    FE->>API: POST /api/register-call (dynamic_data)
    API->>RE: createWebCall(agent_id + 动态变量)
    RE-->>FE: access_token
    FE->>RE: 建立语音通话 (RetellWebClient)
    RE<-->C: 实时语音面试（Agent 多轮追问循环）

    RE->>FE: call_analyzed 事件 → webhook
    FE->>API: POST /api/response-webhook (校验签名)
    API->>API: POST /api/get-call
    API->>RE: call.retrieve(call_id) 获取逐字稿
    API->>OAI: generateInterviewAnalytics (analytics 提示词)
    OAI-->>API: JSON {overallScore, communication, questionSummaries,...}
    API->>SB: 保存分析结果 (is_analysed=true)

    API->>OAI: generate-insights (汇总所有 call_summary)
    OAI-->>API: JSON {insights[]}
    API->>SB: updateInterview(insights)
```

## 3. 提示词分类统计

| 类别 | 数量 | 用途说明 |
|------|------|----------|
| 系统提示词（System Prompt） | 5 | 为每类任务设定专家角色与输出约束（分析专家 / 沟通分析专家 / 洞察专家 / 出题专家 / 语音面试官） |
| 用户/任务处理提示词（User Prompt） | 5 | 承载具体指令、待处理数据与输出 JSON 结构模板 |
| Agent 提示词（含动态变量） | 1 | Retell 语音面试官的行为准则（追问、时长、语气、变量注入） |
| 工具描述（Tool description） | 1 | `end_call` 结束通话工具的触发说明 |

> 说明：此处"系统提示词"与"用户提示词"成对出现；Agent 提示词（`RETELL_AGENT_GENERAL_PROMPT`）同时承担系统与行为准则的角色。

## 4. 大模型应用场景分析

### 场景 1: 自动生成面试问题与描述
- 触发条件: 招聘经理创建面试，填写名称/目标/问题数/时长并点击 "Generate Questions"。
- 使用的提示词: [generate-questions_prompt_zh.md](./translated_prompts/generate-questions_prompt_zh.md)
- 代码位置: [generate-interview-questions/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/generate-interview-questions/route.ts#L19-L32)
- 输入输出: 输入 `{ name, objective, number, context }`（context 来自 PDF 解析）→ 输出 `{ questions: [{question}], description }`。
- 作用: 将岗位说明转化为结构化的面试问题清单，并生成面向候选人的第二人称描述，是面试创建的核心预处理环节。

### 场景 2: AI 语音面试（Agent 多轮对话）
- 触发条件: 候选人打开面试链接并点击 "Start Interview"。
- 使用的提示词: [constants_retell_voice_agent_prompt_zh.md](./translated_prompts/constants_retell_voice_agent_prompt_zh.md)
- 代码位置: [create-interviewer/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/create-interviewer/route.ts#L15-L26)、[register-call/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/register-call/route.ts#L18-L21)
- 输入输出: 输入动态变量 `{ mins, name, objective, questions }` → 输出实时语音对话，最终产出 `transcript`、`recording_url`、`call_analysis`（含 `call_summary`）。
- 作用: 由 Retell AI 托管 gpt-4o 语音 Agent，按照行为准则对候选人进行多轮追问式面试，是产品的核心闭环。

### 场景 3: 面试逐字稿分析与评分
- 触发条件: 通话结束，收到 Retell 的 `call_analyzed` 事件（经 webhook → get-call）。
- 使用的提示词: [analytics_interview_analysis_prompt_zh.md](./translated_prompts/analytics_interview_analysis_prompt_zh.md)
- 代码位置: [analytics.service.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/services/analytics.service.ts#L37-L52)
- 输入输出: 输入 `{ transcript, mainInterviewQuestions }` → 输出 `{ overallScore, overallFeedback, communication, questionSummaries[], softSkillSummary }`。
- 作用: 对每个面试回答进行多维度评分（沟通、自信、清晰度、深度等），并逐题生成总结，供招聘经理查看候选人表现。

### 场景 4: 沟通能力专项分析
- 触发条件: 调用 `POST /api/analyze-communication`（传入 `transcript`）。
- 使用的提示词: [communication-analysis_prompt_zh.md](./translated_prompts/communication-analysis_prompt_zh.md)
- 代码位置: [analyze-communication/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/analyze-communication/route.ts#L26-L39)
- 输入输出: 输入 `transcript` → 输出 `{ communicationScore, overallFeedback, supportingQuotes[], strengths[], improvementAreas[] }`。
- 作用: 对沟通能力做更细粒度的分析，并引用逐字稿原文作为佐证。[待确认] 该接口当前在前端无调用入口。

### 场景 5: 面试洞察汇总
- 触发条件: 调用 `POST /api/generate-insights`（传入 `interviewId`）。
- 使用的提示词: [generate-insights_prompt_zh.md](./translated_prompts/generate-insights_prompt_zh.md)
- 代码位置: [generate-insights/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/generate-insights/route.ts#L29-L58)
- 输入输出: 输入所有 `call_summary` 拼接 + 面试元信息 → 输出 `{ insights: string[3] }`。
- 作用: 汇总某场面试下所有候选人的通话摘要，提炼 3 条用户反馈洞察，回填到面试记录。[待确认] 前端调用入口未在代码中显式发现。

## 5. 上下文工程

### 5.1 整体形态判断
本项目采用 **混合形态**：
- **嵌入型（LLM 作为业务工具）**：问题生成、逐字稿分析、沟通分析、洞察生成，均为"单次请求→结构化 JSON"的确定性流程，LLM 被嵌入到面试创建/分析流水线中，不做自主多轮决策。
- **Agent 型（LLM makes/ends the loop）**：语音面试环节委托给 Retell AI，由 gpt-4o 作为对话的独立决策者，在通话中自主决定何时提问、是否追问、何时结束（通过 `end_call` 工具）。

### 5.2 Agent 循环拆解（语音面试）

语音面试的循环由 Retell AI 托管，逻辑如下：

1. **LLM makes the loop（模型发起循环）**：`RETELL_AGENT_GENERAL_PROMPT` 注入面试目标、时长、候选人姓名与问题清单，模型据此主动开口提问，并在每次提问后强制追加一个后续问题（"Once you ask a question, make sure you ask a follow up question on it"），从而驱动多轮对话。
2. **LLM in the loop（模型在环中）**：每轮候选人的语音经语音识别转为文本，连同历史对话一起作为上下文回传给 gpt-4o，模型结合动态变量中的问题清单判断下一问，且避免重复提问。
3. **LLM ends the loop（模型结束循环）**：模型通过调用 `end_call` 工具在候选人说再见（"bye" / "goodbye" / "have a nice day"）时主动挂断通话；此外前端也会在达到时长上限时调用 `webClient.stopCall()` 作为兜底（代码位置 [call/index.tsx](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/components/call/index.tsx#L113-L116)）。

### 5.3 提供给大模型的工具（Tools）

项目仅向语音 Agent 提供了一个工具：

| 工具 | 类型 | name | Description（原文） | Description（中文翻译） | 价值 |
|------|------|------|---------------------|------------------------|------|
| `end_call_1` | `end_call` | `end_call_1` | "End the call if the user uses goodbye phrases such as 'bye,' 'goodbye,' or 'have a nice day.'" | 当用户说出诸如"bye""goodbye"或"have a nice day"之类的告别语时结束通话。 | 让模型具备"主动结束对话"的能力，是 Agent 闭环的终止条件，避免模型在候选人告别后仍继续纠缠。 |

- 工具声明位置: [create-interviewer/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/create-interviewer/route.ts#L18-L25)，通过 `retellClient.llm.create` 的 `general_tools` 参数注入。
- Retell 的 `end_call` 属于内置工具，无自定义参数 schema；它通过在提示词工具列表中向模型暴露"结束通话"这一行为。

### 5.4 嵌入型场景的上下文构造

每个嵌入型环节的上下文构造方式如下：

- **问题生成（场景 1）**：上下文 = JSON 格式化的面试标题、目标、问题数量 + （可选）PDF 解析出的职位文档文本。提示词约束输出为 `{ questions, description }` 的 JSON，将非结构化的岗位信息结构化为面试问题清单。
- **逐字稿分析（场景 3）**：上下文 = 面试逐字稿 + 编号后的主要问题列表。提示词明确"只用主要问题、不推断新问题"，并给定逐题的评分量表与 JSON schema，引导模型产出可落库的评分对象（`Analytics`）。
- **沟通分析（场景 4）**：上下文 = 单个面试逐字稿。提示词要求输出"引用原文 + 分析 + 优势/改进项"的关联结构，使评分有据可依。
- **洞察生成（场景 5）**：上下文 = 多份通话摘要拼接 + 面试元信息。提示词要求去化名、限 25 词、输出 3 条，产出可直接展示的文本数组。

### 5.5 关键上下文字段来源

| 上下文字段 | 来源 | 说明 |
|-----------|------|------|
| `transcript` | Retell `call.retrieve()` | 语音逐字稿，用于分析与评分 |
| `call_summary` | Retell `call_analysis.call_summary` | 通话自动摘要，用于洞察聚合 |
| `questions` | 面试记录 `interview.questions` | 出题结果，用于逐题总结与语音 Agent 问题清单 |
| `objective` / `name` / `description` | 面试记录 | 用于出题与洞察 |
| PDF 文本 | LangChain `PDFLoader` | 出题时的附加上下文 |

## 6. 环境变量与模型配置

| 变量 | 用途 |
|------|------|
| `OPENAI_API_KEY` | 直连 OpenAI gpt-4o（问题生成、分析、洞察、沟通分析） |
| `RETELL_API_KEY` | 语音通话托管与语音 Agent（底层 gpt-4o） |

- 所有直连 GPT 调用统一使用 `model: "gpt-4o"` + `response_format: { type: "json_object" }` + `maxRetries: 5`。
- 语音 Agent 在 [create-interviewer/route.ts](file:///Users/dong/Documents/开源项目/Foloup/FoloUp-main/src/app/api/create-interviewer/route.ts#L15-L26) 中以 `model: "gpt-4o"` 创建 Retell LLM，并绑定两个配音（Lisa=Chloe、Bob=Brian）的 Agent。

## 7. 附录：待确认事项
1. `POST /api/analyze-communication`（沟通分析）在现有前端代码中未发现调用入口。
2. `POST /api/generate-insights`（洞察生成）在现有前端代码中未发现显式调用入口。
3. `langchain` 依赖仅用于 PDF 解析（`PDFLoader`），未用于链路编排或 Agent 框架。