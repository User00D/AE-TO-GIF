# ValueCell 大模型应用分析报告

## 1. 项目概述

- **项目名称**: ValueCell（`valuecell`，版本 0.1.20）
- **项目描述**: 依据 README，ValueCell 是一个"社区驱动的、面向金融应用的多 Agent 平台"（community-driven, multi-agent platform for financial applications），目标是构建去中心化的金融 Agent 社区。它提供一组"顶级投资 Agent"，帮助用户完成选股、研究、跟踪乃至交易。系统将敏感信息保存在本地设备上，以保证数据安全。
- **主要功能**（据 README "Key Features"）:
  - **DeepResearch Agent（深度研究 Agent）**: 自动检索并分析基本面文档，生成准确的数据洞察与可解释的摘要。
  - **Strategy Agent（策略 Agent）**: 支持多加密资产与多策略智能交易，自动执行用户策略。
  - **News Retrieval Agent（新闻检索 Agent）**: 支持个性化定时新闻推送，实时跟踪关键信息。
  - **应用形态**: 桌面应用（Tauri）+ 本地 Python 后端；另有云端版本 valuecell.ai 提供 A 股深度研究与市场分析。
- **技术栈**:
  - **后端**: Python ≥ 3.12，包管理使用 `uv`（`python/pyproject.toml`）。
  - **Agent 框架**: `agno`（≥2.0），统一封装 Agent、工具调用、结构化输出、知识库与会话存储。
  - **Agent 间通信**: `a2a-sdk`（Google Agent2Agent 协议），实现"本地编排器 + 远程 Agent 服务"的分布式结构。
  - **服务层**: FastAPI + uvicorn + SQLAlchemy + SQLite。
  - **知识库（RAG）**: `agno` Knowledge + LanceDB 向量库 + 外部嵌入模型。
  - **金融数据**: `edgartools`（SEC EDGAR 申报）、`akshare`/`baostock`（A 股）、`yfinance`（美股行情）、`ccxt`（加密货币交易所）、RootData（加密项目/VC/人物）。
  - **前端**: React Router 7 + TypeScript + Tauri 2 + Radix UI + ECharts + i18next。
  - **模型供给**: 通过 `python/configs/providers/*.yaml` 统一抽象多 provider（OpenRouter、Google、SiliconFlow、DashScope、Azure OpenAI、Ollama 等）。

## 2. 项目逻辑与数据流分析

系统采用"**三级 Agent 编排**"结构：前台分诊（Super Agent）→ 规划路由（Planner）→ 专家执行（远程 Agent）；
其中交易类 Agent 又自成一套"定时循环 + LLM 决策"的闭环。

```mermaid
sequenceDiagram
    autonumber
    participant U as 用户（Tauri 前端）
    participant API as FastAPI /api
    participant O as AgentOrchestrator
    participant SA as SuperAgent（LLM ①）
    participant P as ExecutionPlanner（LLM ②）
    participant TE as TaskExecutor
    participant RA as ResearchAgent（LLM ③）
    participant NA as NewsAgent（LLM ③-2）
    participant KB as 知识库（LanceDB）
    participant TV as 交易 Agent 运行时（LLM ④）
    participant EX as 交易所 / 模拟撮合

    U->>API: 发送自然语言请求
    API->>O: UserInput(conversation_id, query, ...)
    O->>SA: run(query) —— 用 SUPER_AGENT_INSTRUCTION 分诊
    alt decision = answer
        SA-->>U: 直接流式回答（不调用工具）
    else decision = handoff_to_planner
        SA->>P: enriched_query + target_agent_name
        P->>P: 调用 tool_get_enabled_agents / tool_get_agent_description
        Note over P: agentcard_to_prompt() 把 Agent Card 拼成提示词上下文
        alt 需要确认周期日程
            P-->>U: adequate=false + guidance_message（暂停等待确认）
            U->>P: 用户确认（或内联确认）
        end
        P->>P: 输出 PlannerResponse（tasks / pattern / schedule_config）
        P->>TE: ExecutionPlan(tasks)
    end

    TE->>RA: A2A 派发任务（或按日程定时触发）
    RA->>RA: 依据 KNOWLEDGE_AGENT_INSTRUCTION 规划工具调用
    RA->>RA: fetch_*_sec_filings / fetch_ashare_filings / web_search
    RA->>KB: 写入抓取到的申报文档（自动入库）
    RA->>KB: 检索知识库（确认/补充事实）
    RA-->>U: 流式回答（含 file 引用链接）

    TE->>NA: A2A 派发新闻任务
    NA->>NA: web_search / get_breaking_news / get_financial_news
    NA-->>U: 纯新闻内容流

    Note over TV: 交易类 Agent 独立运行，由 decide_interval 驱动的循环
    loop 每个决策周期（decide_interval）
        TV->>TV: 计算特征（1m 结构趋势 / 1s 实时信号）
        TV->>TV: LlmComposer 组装 JSON Context（summary/market/features/positions/constraints）
        TV->>TV: LLM 决策 → TradePlanProposal（items + rationale）
        TV->>TV: _normalize_plan 施加硬约束（数量取整/最小名义额/购买力）
        TV->>EX: 执行下单（实盘或模拟盘）
        EX-->>TV: 成交结果 / 拒单原因
        TV->>TV: 记录历史 → 重建 digest（含 Sharpe 比率）
    end
    TV-->>U: 流式事件 +（可选）Discord 推送决策理由
```

### 关键数据流节点

| 环节 | 输入 | 处理 | 输出 |
|------|------|------|------|
| 分诊 | 用户原始 query | `SuperAgent` + `SUPER_AGENT_INSTRUCTION`，结构化输出 `SuperAgentOutcome` | `answer` 或 `handoff_to_planner(enriched_query)` |
| 规划 | enriched_query + 可用 Agent Card | `ExecutionPlanner` + `PLANNER_INSTRUCTION`，可调用 2 个"查 Agent"工具，支持 HITL 暂停 | `ExecutionPlan(tasks)` 或 `guidance_message` |
| 派发 | `Task` | `TaskExecutor` 通过 A2A 协议把 query 发给目标 Agent，并按 `schedule_config` 计算下次执行时间 | 流式 `BaseResponse` 事件 |
| 研究 | 任务 query + 历史 + 依赖上下文 | `ResearchAgent` 的 ReAct 循环（工具调用 + 知识库检索） | 带引用的 Markdown 回答；同时把新申报文档写入向量库 |
| 新闻 | 任务 query | `NewsAgent` 调用搜索类工具 | 纯新闻文本 |
| 交易 | 市场特征 + 组合状态 + 策略提示词 | `LlmComposer` 每周期一次 LLM 决策 | `TradeInstruction` 列表 + rationale，交由执行网关落单 |

## 3. 提示词分类统计

| 类别 | 数量 | 用途说明 |
|------|------|----------|
| 系统/角色提示词（Instruction） | 6 | 定义身份、职责边界与行为原则：Super Agent 分诊、Planner 规划、Research Agent 研究、News Agent 播报、交易决策系统提示词、网格参数顾问系统提示词 |
| 输出契约/期望输出（Expected Output） | 3 | 用 few-shot 示例约束输出结构：Super Agent 决策 JSON、Planner 任务 JSON、Research Agent 写作风格与引用规范 |
| 动态上下文模板（代码内拼接） | 3 | 运行时生成：交易决策每轮 JSON Context（`_build_llm_prompt`）、网格参数顾问上下文与调节指令、Agent Card → 提示词转换（`agentcard_to_prompt`） |
| 用户策略提示词模板（Strategy Templates） | 3 | 用户可选择/自定义的交易风格说明：`default.txt`（保守）、`aggressive.txt`（激进）、`insane.txt`（极端激进，仅演示） |
| 工具层/业务兜底提示词 | 1 | 资产搜索的 LLM 兜底：把模糊查询映射为标准 ticker 格式（system + user 两段） |
| **合计** | **16 个提示词单元**（15 份文档，其中 ticker 生成含 system/user 两段） | |

补充：`python/configs/agent_cards/*.json` 中的 4 张 Agent Card 不直接作为提示词传入，而是作为"隐式提示词"由工具动态注入规划器上下文（见第 5 节）。

## 4. 大模型应用场景分析

### 场景 1: 前台分诊与直接作答（Super Agent）

- **触发条件**: 用户在会话中发送任意消息（每个新请求都先经过分诊）。
- **使用的提示词**: [SUPER_AGENT_INSTRUCTION](./translated_prompts/core_super_agent_prompts_super_agent_triage_prompt_zh.md)、[SUPER_AGENT_EXPECTED_OUTPUT](./translated_prompts/core_super_agent_prompts_super_agent_expected_output_prompt_zh.md)
- **代码位置**: `python/valuecell/core/super_agent/core.py:63`（Agent 构造）、`:132`（`run()` 流式调用）
- **输入输出**: 输入用户 query + 最近 5 轮历史 + 当前时间；输出 `SuperAgentOutcome{decision, answer_content, enriched_query, reason}`。
- **作用**: 用一个**廉价、快速的单次 LLM 调用**过滤掉"2+2 等于几"这类无需工具的请求，避免动辄启动完整规划与远程 Agent，降低延迟与成本；同时通过"禁止失败主义措辞 + 有疑问就 handoff"的规则，把不确定性全部推给下游。

### 场景 2: 任务规划与 Agent 路由（Planner）

- **触发条件**: Super Agent 返回 `handoff_to_planner`。
- **使用的提示词**: [PLANNER_INSTRUCTION](./translated_prompts/core_plan_prompts_planner_instruction_prompt_zh.md)、[PLANNER_EXPECTED_OUTPUT](./translated_prompts/core_plan_prompts_planner_expected_output_prompt_zh.md)、[agentcard_to_prompt](./translated_prompts/core_plan_planner_agentcard_to_prompt_zh.md)
- **代码位置**: `python/valuecell/core/plan/planner.py:103`（Agent 构造）、`:357` 与 `:379`（两个 Agent Card 工具）、`:389`（`agentcard_to_prompt` 转换函数）
- **输入输出**: 输入 `PlannerInput{target_agent_name, query}` + 工具返回的 Agent 能力清单；输出 `PlannerResponse{tasks[], adequate, reason, guidance_message}`。
- **作用**: 实现 **"LLM 做路由"**。设计上刻意追求"透明代理"——用户指定了 Agent 就原样直通、不做改写；未指定时通过工具读取 Agent Card 做语义匹配。同时它是**唯一引入人类确认（HITL）的环节**：识别到周期性日程时返回 `adequate=false`，暂停执行等待用户确认。

### 场景 3: 深度研究与财报问答（Research Agent）

- **触发条件**: 规划器把任务路由给 `ResearchAgent`（例如"茅台2024年年报的营收是多少？"）。
- **使用的提示词**: [KNOWLEDGE_AGENT_INSTRUCTION](./translated_prompts/agents_research_agent_prompts_knowledge_agent_instruction_prompt_zh.md)、[KNOWLEDGE_AGENT_EXPECTED_OUTPUT](./translated_prompts/agents_research_agent_prompts_knowledge_agent_expected_output_prompt_zh.md)
- **代码位置**: `python/valuecell/agents/research_agent/core.py:44`
- **输入输出**: 输入 query + 会话历史（最近 3 轮）+ 依赖上下文；输出带 `file://` 本地文档引用的 Markdown 回答，并**副作用式地**把抓取到的申报文件写入 LanceDB 知识库。
- **作用**: 这是项目中最"重"的 AI 场景，也是唯一真正的 **ReAct 自主循环**。提示词显式给出工具清单、路由矩阵（事实类→先查申报；分析类→先查知识库）、调用预算（每轮回答最多 3 次申报工具调用）、参数映射规则（filing_date 与 period_of_report 的区分、A 股中文→英文）以及失败回退策略。

### 场景 4: 新闻检索与播报（News Agent）

- **触发条件**: 任务被路由给 `NewsAgent`，或用户订阅定时新闻。
- **使用的提示词**: [NEWS_AGENT_INSTRUCTIONS](./translated_prompts/agents_news_agent_prompts_news_agent_instructions_prompt_zh.md)
- **代码位置**: `python/valuecell/agents/news_agent/core.py:33`；工具位于 `python/valuecell/agents/news_agent/tools.py`
- **输入输出**: 输入新闻查询；输出"纯新闻"文本（无引导语、无解释、无后续建议）。
- **作用**: 通过强约束的输出格式（"绝不包含'我来为您查找……'"）压制 LLM 的寒暄倾向，让结果可直接作为播报内容或定时推送体使用。值得注意：这里的"搜索"并非独立检索系统，而是**用带联网能力的模型当检索引擎**（Gemini + Search grounding，或 Perplexity Sonar）。

### 场景 5: 提示词驱动的交易决策循环（Prompt-based Strategy Agent）

- **触发条件**: 用户创建策略并启动（前端显式指定 `PromptBasedStrategyAgent`，走 `target_agent_name` 直通路径）。
- **使用的提示词**: [交易决策 SYSTEM_PROMPT](./translated_prompts/trading_decision_prompt_based_system_prompt_zh.md)、[每轮 JSON 上下文](./translated_prompts/trading_decision_prompt_based_composer_build_llm_prompt_zh.md)、[default.txt](./translated_prompts/prompt_strategy_agent_templates_default_prompt_zh.md)、[aggressive.txt](./translated_prompts/prompt_strategy_agent_templates_aggressive_prompt_zh.md)、[insane.txt](./translated_prompts/prompt_strategy_agent_templates_insane_prompt_zh.md)
- **代码位置**: `python/valuecell/agents/common/trading/decision/prompt_based/system_prompt.py:11`、`composer.py:64/138/185`、`agents/common/trading/_internal/coordinator.py`
- **输入输出**: 输入每周期更新的 `ComposeContext`（features / portfolio / digest）；输出 `TradePlanProposal{items[], rationale}` → 经 `_normalize_plan()` 归一化为 `TradeInstruction[]` → 交执行网关。
- **作用**: LLM 成为**交易决策者**。提示词设计有两大特色：
  1. **两层提示词分离**：系统层只写"角色 + IO 契约 + 约束校验"，交易风格完全外置到用户模板，从而做到"同一套执行器、无限种策略"。
  2. **引入绩效自适应**：每次调用都会把上一周期的夏普比率喂进上下文，并给出明确的分档行为指南（如"夏普 < -0.5 时立刻停止交易至少 6 个周期"）。这实际上是把"策略反思"编码进提示词，用 LLM 替代传统量化中的参数调整环节。

### 场景 6: 网格策略参数的动态调优（GridParamAdvisor）

- **触发条件**: 网格策略开启 `use_llm_params=True`，每 300 秒或市场变化超过 1% 时刷新。
- **使用的提示词**: [网格参数顾问 SYSTEM_PROMPT](./translated_prompts/trading_grid_composer_llm_param_advisor_prompt_zh.md)
- **代码位置**: `python/valuecell/agents/common/trading/decision/grid_composer/llm_param_advisor.py:17`、`:160`、`:172`
- **输入输出**: 输入 `snapshot_metrics`（价格/涨跌幅/成交量/持仓量/资金费率）+ `previous_params` + `portfolio`；输出 `GridParamAdvice`（步长、最大步数、基础仓位比例、可选网格边界与格数、理由）。
- **作用**: 典型的"**LLM 作为业务工具**"嵌入模式——LLM 不决定买卖，只输出**参数**，由确定性规则引擎执行网格交易。这样既让参数能随市场状态自适应，又保留了策略逻辑的完全可解释性与可回测性；LLM 失败时自动回退默认参数。

### 场景 7: 资产搜索的 LLM 兜底（Ticker 生成）

- **触发条件**: 用户搜索资产，而所有数据源适配器都返回空结果。
- **使用的提示词**: [Ticker 生成提示词](./translated_prompts/adapters_assets_manager_ticker_generation_prompt_zh.md)
- **代码位置**: `python/valuecell/adapters/assets/manager.py:381`（system）、`:386`（user）、`:415`（Agent 调用）
- **输入输出**: 输入用户搜索词；输出候选 ticker 字符串数组（如 `["NASDAQ:AAPL", "HKEX:00700"]`）。
- **作用**: 用 LLM 处理"用户口中的名字 → 标准化交易代码"这种模糊映射（含中英文公司名、币种、指数、ETF）。工程上做了严格防护：仅作为兜底路径触发，且生成的每个 ticker 都要经过适配器存在性与资产信息双重校验才会被采纳。

## 5. 上下文工程

### 5.1 "LLM 在循环中"的三种形态

项目对 LLM 的使用并非单一模式，而是按场景在三种形态间切换：

| 形态 | 代表模块 | LLM 是否决定循环 | 说明 |
|------|----------|------------------|------|
| **LLM 即循环（LLM makes / in / ends the loop）** | ResearchAgent、NewsAgent | 是 | Agent 自主决定调用哪个工具、是否继续调用、何时结束并输出。循环由 `agno` 的 ReAct 机制驱动，终止条件是模型不再发出工具调用。 |
| **LLM 在循环中，但循环由代码驱动** | 交易 Agent（PromptBased / Grid） | 部分 | 循环节拍由 `decide_interval` 定时器与 `coordinator.py` 控制；LLM 每轮只做一次"决策"或"给参数"，不决定是否继续循环、也不决定何时退出策略。这属于 "LLM in the loop" 而非 "LLM makes the loop"。 |
| **LLM 作为单次路由器/工具** | SuperAgent、Planner、GridParamAdvisor、Ticker 生成 | 否 | 单次输入输出，无多轮自主交互。Planner 具备工具调用能力，但最多一次规划 + 一次 HITL 确认。 |

**研究 Agent 的循环细节（最完整的 Agent 形态）**：

1. **循环发起者**：拿到任务的 LLM 看到 `<tools>` 清单后自主选择工具（例如先调用 `fetch_periodic_sec_filings`）。
2. **循环推进者**：工具返回的申报内容会被写入 LanceDB；提示词强制要求"调用申报工具后**必须**再做一次知识库检索"，形成"申报 → 入库 → 检索 → 综合"的自增强链条。
3. **循环约束者**：提示词给出调用预算（每轮回答不超过 3 次申报工具调用）、路由矩阵与失败回退策略，防止无限循环与资源浪费。
4. **循环终止者**：当模型不再请求工具、直接产出带引用的最终答案时循环结束；`stream()` 把 `ToolCallStarted`、`ToolCallCompleted`、`RunContent` 事件实时透传给前端。

**交易 Agent 的循环细节（LLM 被嵌入业务流程）**：

```text
数据采集（行情 + 历史）
   ↓
特征计算（1m 结构性趋势 240 周期 / 1s 实时信号 180 周期）
   ↓
上下文构造（summary + market + features + positions + constraints + strategy_prompt）
   ↓
LLM 决策（SYSTEM_PROMPT + JSON Context）→ TradePlanProposal
   ↓
确定性归一化（_normalize_plan：数量取整、min_notional、购买力/杠杆上限、禁止对冲）
   ↓
执行（实盘 ccxt / 模拟盘 paper_trading）→ 拒单原因回写 rationale
   ↓
历史记录 → digest 重建（胜率、盈亏、Sharpe）
   ↓
（下一周期）Sharpe 反馈进上下文，模型据此收紧或放宽交易频率
```

这条链路体现了"**给模型喂什么上下文，就得到什么样的输出**"：账户状态决定"能不能开仓"，市场特征决定"往哪开"，
约束条件决定"最多开多大"，历史绩效（Sharpe）决定"该不该少开"。LLM 的输出被严格限制在结构化的 `TradePlanProposal` 中，
后续还有一层代码护栏兜底——**提示词负责引导，代码负责强制**。

### 5.2 工具清单与调用 Schema

> 说明：项目基于 `agno` 框架，工具的 schema 直接从 Python 函数签名与 docstring 生成（函数名 + 参数类型 + docstring 即"给模型看的说明书"）。
> 因此下列 description 均取自源码 docstring，并翻译为中文。

#### A. 规划器工具（`ExecutionPlanner`，`core/plan/planner.py:103`）

| 工具 | 签名（Schema） | description（中文） | 提供的上下文价值 |
|------|---------------|---------------------|------------------|
| `tool_get_enabled_agents` | `() -> str` | 返回所有**可规划** Agent 的卡片描述（由 `agentcard_to_prompt()` 拼接，格式为 `<AgentName>...</AgentName>`），包含 name、description、skills（id、name、description、examples、tags）。 | 让规划器在"用户没指定 Agent"时，通过语义比对技能清单选出最合适的执行者。它把"系统里有哪些能力"这一信息按需注入，避免把全部 Agent 说明写死在系统提示词里，从而支持 Agent 热插拔。 |
| `tool_get_agent_description` | `(agent_name: str) -> str` | 返回指定 Agent 的人类可读描述或卡片；若不存在则返回 "The requested agent could not be found or is not available." | 用于**深挖单个候选 Agent 的能力**，特别是判断它是否具备 `monitor`、`alerts`、`notifications`、`tracking` 类技能，从而决定该不该创建周期性任务。 |

重要设计：`get_planable_agent_cards()`（`core/agent/connect.py:660`）会跳过 `hidden` 或 `planner_passthrough` 的 Agent。
因此交易类 Agent（`PromptBasedStrategyAgent`、`GridStrategyAgent`）不会出现在自动选择列表中，只能由前端显式指定。

#### B. 研究 Agent 工具（`ResearchAgent`，`agents/research_agent/sources.py`）

| 工具 | 签名（Schema） | description（中文） | 提供的上下文价值 |
|------|---------------|---------------------|------------------|
| `fetch_periodic_sec_filings` | `(cik_or_ticker: str, forms: list[str] \| str = "10-Q", year: int \| list[int] \| None = None, quarter: int \| list[int] \| None = None, limit: int = 10)` | 抓取定期 SEC 申报（10-K/10-Q）并写入知识库。适用于披露周期固定的报告；按 filing_date 过滤 year/quarter；若省略 year 则用 `latest(limit)` 取最新；提供 quarter 时必须同时提供 year。返回 `List[SECFilingResult]`。 | 提供**一手权威财务事实**（营收、净利润、MD&A 原文）。同时把文档落地并入库，使后续检索可复用、避免重复抓取外部接口。 |
| `fetch_event_sec_filings` | `(cik_or_ticker: str, forms: list[str] \| str = "8-K", start_date: str \| date \| None = None, end_date: str \| date \| None = None, limit: int = 10)` | 抓取事件驱动型申报（如 8-K、Form 3/4/5），支持日期范围与数量限制；无日期范围时用 `latest(limit)` 提效。 | 覆盖**突发事件与内部人持股变化**类信息。这类信息无法从定期报告推导，是"何时发生什么"的关键上下文。 |
| `fetch_ashare_filings` | `(stock_code: str, report_types: list[str] \| str = "annual", year: int \| list[int] \| None = None, quarter: int \| list[int] \| None = None, limit: int = 10)` | 从巨潮资讯（CNINFO）抓取 A 股申报并导入知识库。`report_types` **仅支持英文** `"annual"` / `"semi-annual"` / `"quarterly"`，中文参数会抛 `ValueError`；`quarter` 仅在季度报告时适用且需提供 `year`。 | 把覆盖面从美股扩展到 **A 股**，是产品面向中文市场的重要能力。提示词中专门写了"中文→英文"映射规则，把模型的语言理解与严格 API 参数之间的鸿沟显式抹平。 |
| `web_search` | `(query: str) -> str` | 搜索网络并返回顶部结果摘要。支持两种后端：当 `WEB_SEARCH_PROVIDER=google` 且存在 `GOOGLE_API_KEY` 时使用 Gemini + Search grounding，否则回退 OpenRouter 的 `perplexity/sonar`。 | 覆盖**时效性强或不在申报文件中的信息**（新闻稿、IR 页面、交易所公告）。提示词要求把时间范围与站点过滤写进 query（如 `after:2025-01-01`、`site:investor.apple.com`），这是"用模型当检索器"时的关键技巧。 |
| `search_crypto_projects` | `(query: str, limit: int = 10) -> str` | 在 RootData 上按关键词搜索加密货币项目，适用于询问加密项目、代币或区块链生态。返回含名称、描述、标签与关键指标的 JSON 字符串。 | 为加密资产研究提供**基本面元数据**（项目定位、赛道标签），补充行情数据无法提供的"这是什么"上下文。 |
| `search_crypto_vcs` | `(query: str, limit: int = 5) -> str` | 在 RootData 上搜索风投机构与加密投资者，适用于询问 VC、投资机构或加密投资人。返回机构描述、投资组合与链接。 | 提供**资金侧视角**（谁在投什么），用于判断项目背书与赛道热度。 |
| `search_crypto_people` | `(query: str, limit: int = 5) -> str` | 在 RootData 上搜索加密行业人物（创始人、高管、投资人），返回姓名、职位、关联项目与链接。 | 提供**人的维度**上下文，用于尽调团队背景与关联关系。 |

除上述显式工具外，研究 Agent 还挂载了 `knowledge=<LanceDb>`（`search_knowledge=True`），使模型可对已入库文档做向量检索。
该知识库由 `fetch_*_filings` 工具**自动写入**（`insert_md_file_to_knowledge` / `insert_pdf_file_to_knowledge`），形成"抓取即入库、入库即可检索"的闭环。
若嵌入模型不可用，知识库会优雅降级为 `None`，此时 Agent 以"纯工具模式"运行。

#### C. 新闻 Agent 工具（`NewsAgent`，`agents/news_agent/tools.py`）

| 工具 | 签名（Schema） | description（中文） | 提供的上下文价值 |
|------|---------------|---------------------|------------------|
| `web_search` | `(query: str) -> str` | 搜索网络并返回顶部结果摘要，支持 Google Gemini（带搜索接地）与 Perplexity Sonar（经 OpenRouter）两种后端。 | 通用实时信息检索能力。 |
| `get_breaking_news` | `() -> str` | 获取突发新闻与紧急更新。内部以固定查询 `"breaking news urgent updates today"` 调用 `web_search`；失败时返回错误字符串而非抛异常。 | 无需用户提供查询词即可获取**最新动态**，适合定时播报场景。 |
| `get_financial_news` | `(ticker: str \| None = None, sector: str \| None = None) -> str` | 获取财经与市场新闻，可指定股票代码或行业板块；内部把当日日期拼进查询以强化时效性。 | 为**个股/行业跟踪**提供结构化入口，比裸查询更可控。 |

注意：这三个工具的"检索"本质上是**把查询转发给另一个 LLM**（Gemini 或 Perplexity）。
也就是说，项目在"工具层"再次调用了大模型——这是一个值得关注的成本与延迟设计点。

#### D. 交易 Agent：无工具，改为结构化输出 + 代码护栏

交易类 Agent（`LlmComposer`、`GridParamAdvisor`）**没有向模型暴露任何工具**，而是采用另一条路线：

| 机制 | 实现 | 作用 |
|------|------|------|
| 结构化输出（`output_schema`） | `TradePlanProposal` / `GridParamAdvice`（pydantic 模型） | 把模型输出强约束为可执行的数据结构，而非自由文本；解析失败时返回带错误信息的空计划，而不是崩溃。 |
| 每轮 JSON 上下文 | `_build_llm_prompt()` 序列化 `summary`、`market`、`features`、`positions`、`constraints`、`strategy_prompt` | 用"喂状态"替代"给工具"：模型不需要主动查询，因为所有决策所需状态每轮都被完整提供。 |
| 代码侧硬护栏 | `_normalize_plan()`（数量对齐 `quantity_step`、下限 `min_trade_qty`、上限 `max_order_qty`/`max_position_qty`、`min_notional`、购买力校验、禁止同标的多空并存） | 即使模型输出越界，执行层也会截断或丢弃。这是"提示词引导 + 代码强制"双层防护的核心。 |
| 模型能力适配 | `model_should_use_json_mode(model)` | 针对不同 provider 的 JSON 模式兼容性做适配（例如 DashScope 要求消息中含 "json" 字样），避免结构化输出在部分模型上失败。 |

### 5.3 上下文构造的共性手法

综合全部场景，项目在上下文工程上有几条反复出现的手法：

1. **`add_datetime_to_context` + `add_history_to_context`**：核心 Agent（SuperAgent、Planner、ResearchAgent）统一由框架自动注入"当前时间"与"最近 N 轮历史"（`num_history_runs` 分别为 5、5、3），并开启 `read_chat_history` 与 `enable_session_summaries`，避免模型在多轮对话中失忆。
2. **用 few-shot 示例替代抽象规则**：三个 `*_EXPECTED_OUTPUT` 常量都大量使用具体示例（尤其是 Planner 的 5 组输入输出对），把"日程确认"这类复杂分支用示例讲清楚，比纯规则描述更可靠。
3. **显式语言策略**：所有面向用户的 Agent 都声明"跟随用户语言"，并特别标注"必须保持英文的技术参数不要翻译"（如 A 股的 `report_types`），避免本地化破坏 API 调用。
4. **优雅降级**：SuperAgent 在模型不可用时直接返回 `handoff_to_planner`；ResearchAgent 在嵌入模型不可用时退化为纯工具模式；GridParamAdvisor 在 LLM 失败时回退默认参数。这些降级规则本身也被写进了提示词（"若能力不足则交接，而不是拒绝"）。
5. **用依赖注入传递上下文**：`ResearchAgent.stream()` 通过 `dependencies=build_ctx_from_dep(dependencies)` 与 `add_dependencies_to_context=True` 把上游任务上下文注入模型，实现跨 Agent 的上下文传递。

## 6. 输出文件清单

所有产物位于项目根目录的 `ai_analysis/` 下：

```text
ai_analysis/
├── AI_MODEL_USAGE_ANALYSIS.md                          # 本报告
└── translated_prompts/
    ├── INDEX.md                                        # 提示词索引
    ├── core_super_agent_prompts_super_agent_triage_prompt_zh.md
    ├── core_super_agent_prompts_super_agent_expected_output_prompt_zh.md
    ├── core_plan_prompts_planner_instruction_prompt_zh.md
    ├── core_plan_prompts_planner_expected_output_prompt_zh.md
    ├── core_plan_planner_agentcard_to_prompt_zh.md
    ├── agents_research_agent_prompts_knowledge_agent_instruction_prompt_zh.md
    ├── agents_research_agent_prompts_knowledge_agent_expected_output_prompt_zh.md
    ├── agents_news_agent_prompts_news_agent_instructions_prompt_zh.md
    ├── trading_decision_prompt_based_system_prompt_zh.md
    ├── trading_decision_prompt_based_composer_build_llm_prompt_zh.md
    ├── trading_grid_composer_llm_param_advisor_prompt_zh.md
    ├── prompt_strategy_agent_templates_default_prompt_zh.md
    ├── prompt_strategy_agent_templates_aggressive_prompt_zh.md
    ├── prompt_strategy_agent_templates_insane_prompt_zh.md
    └── adapters_assets_manager_ticker_generation_prompt_zh.md
```

## 7. 待确认与遗留问题

| 项 | 位置 | 说明 |
|----|------|------|
| 模板变量未替换 | `server/services/strategy_service.py:268` | `insane.txt` 末尾声明的 `{max_positions}`、`{max_leverage}` 等占位符，在 `final_prompt = prompt_item.content` 时**未做任何替换**，会原样送入模型，推测属于设计遗留。 |
| `expected_output` 未启用 | `core/super_agent/core.py:69` | `SUPER_AGENT_EXPECTED_OUTPUT` 被注释掉，实际只依赖 `output_schema`；该常量当前处于"文档"状态。 |
| 文档命名不一致 | `core/plan/prompts.py:5` | 模块 docstring 称 `PLANNER_INSTRUCTIONS`，实际常量名为 `PLANNER_INSTRUCTION`。 |
| JSON 格式笔误 | `core/plan/prompts.py:96` | `PLANNER_EXPECTED_OUTPUT` 的 `<response_json_format>` 示例中，`tasks` 数组外层缺少 `{`。 |
| 新闻工具存在嵌套模型调用 | `agents/news_agent/tools.py` | 三个"新闻工具"内部实际调用了另一个 LLM（Gemini/Perplexity）做检索，存在延迟与成本叠加。 |
| insane 模板未自动入库 | `server/db/init_db.py` | 初始化只写入 `default.txt` 与 `aggressive.txt`，`insane.txt` 需手动导入。 |
