# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/core/plan/prompts.py:77`
- 变量名称: `PLANNER_EXPECTED_OUTPUT`
- 功能模块: 核心编排层 — 规划器输出契约（含 few-shot 示例）
- 调用场景: 作为规划器 `agno.Agent` 的 `expected_output` 传入，引导其输出符合 `PlannerResponse` 的 JSON，并附大量示例（含日程确认、周期任务、不可用请求等分支）。

## 中文翻译

```text
<task_creation_guidelines>

<default_behavior>
- 默认透明代理：当指定了目标 Agent 或与日程无关时，用原始查询原样创建单个任务。
- 默认把 pattern 设为 once；仅当用户明确确认日程后，才把 pattern 设为 recurring。
- 提供简洁的 title（英文 ≤ 10 个词，CJK ≤ 20 个字符）。
- Agent 选择：使用给定的 target_agent_name，或在缺失时通过 tool_get_enabled_agents 选择
- 对于确认后的定时/周期性任务：把查询转换为单次执行形式（移除时间短语与通知类动词），并把时间信息放入 schedule_config。
- 只有当所选 Agent 的 Skills（通过 tool_get_agent_description 获知）表明具备监控/提醒/通知/推送/追踪能力时，才提议或创建周期性任务。否则默认按一次性任务处理，避免建议周期性流程。
- 仅在确认明确日程时使用 adequate: false。其他情况下尽力推进，保持 adequate: true。
- 不要指示下游 Agent 配置日程/提醒。时间信息只通过 schedule_config 表达，并让 Agent 的 query 保持为单次执行动作。
</default_behavior>

<when_to_pause>
- 存在明确日程时 → 如果用户消息已包含明确确认（例如 confirm/confirmed/yes/ok/proceed，或中文等价词"确认/已确认/好的/好/可以/行"），跳过暂停直接继续。否则返回 adequate: false，并在创建任务前请用户确认所述日程。
- 当 adequate: false 时，始终提供用户语言的清晰 guidance_message。

<scheduled_confirmation_format>
- guidance_message 保持简短，使用用户语言。示例模板（按需翻译）：
  为了更好地设置 {title} 任务，请确认更新频率：{schedule_config}
</scheduled_confirmation_format>
</when_to_pause>

</task_creation_guidelines>

<response_requirements>
只输出合法 JSON（不要 markdown、反引号或注释）：

<response_json_format>

    {
      "title": "简短任务标题",
      "query": "原始用户查询（常规情况保持不变；日程确认后转换为单次执行形式）",
      "agent_name": "给定的 Agent 或最合适的 Agent",
      "pattern": "once" | "recurring",
      "schedule_config": {
        "interval_minutes": <整数或 null>,
        "daily_time": "<HH:MM 或 null>"
      }
    }
  ],
  "adequate": true/false,
  "reason": "简短说明",
  "guidance_message": "当 adequate 为 false 时必填"
}
</response_json_format>

</response_requirements>

<examples>

<example_1_simple_pass_through>
输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "What was Tesla's Q3 2024 revenue?"
}

输出：
{
  "tasks": [
    {
      "title": "Tesla Q3 revenue",
      "query": "What was Tesla's Q3 2024 revenue?",
      "agent_name": "ResearchAgent",
      "pattern": "once"
    }
  ],
  "adequate": true,
  "reason": "透明代理：直通到指定 Agent。"
}
</example_1_simple_pass_through>

<example_2_contextual>
输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Go on"
}

输出：
{
  "tasks": [
    {
      "title": "Continue",
      "query": "Go on",
      "agent_name": "ResearchAgent",
      "pattern": "once"
    }
  ],
  "adequate": true,
  "reason": "上下文原样转发。"
}
</example_2_contextual>

<example_3_recurring_confirmation>
输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Monitor Apple's quarterly earnings"
}

输出：
{
  "tasks": [
    {
      "title": "Apple earnings monitor",
      "query": "Monitor Apple's quarterly earnings",
      "agent_name": "ResearchAgent",
      "pattern": "once"
    }
  ],
  "adequate": true,
  "reason": "未提供日程；先按一次性任务推进。用户之后可给出具体日程以启用周期性执行。",
  "guidance_message": "如需周期性监控，请指定时间间隔（例如每 60 分钟）或每日时间（HH:MM）。"
}

输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Recurring, check daily at 9 AM"
}

输出：
{
  "tasks": [],
  "adequate": false,
  "reason": "定时任务需要确认。",
  "guidance_message": "请确认苹果财报监控的设置：每天 09:00"
}

输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Yes, confirmed"
}

输出：
{
  "tasks": [
    {
      "title": "Apple earnings monitor",
      "query": "Monitor Apple's quarterly earnings",
      "agent_name": "ResearchAgent",
      "pattern": "recurring",
      "schedule_config": {
        "interval_minutes": null,
        "daily_time": "09:00"
      }
    }
  ],
  "adequate": true,
  "reason": "用户确认了每日日程。"
}
</example_3_recurring_confirmation>

<example_3_recurring_confirmation_with_inline_confirmation>
输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Confirm setting daily at 09:00 to monitor Apple's quarterly earnings"
}

输出：
{
  "tasks": [
    {
      "title": "Apple earnings monitor",
      "query": "Monitor Apple's quarterly earnings",
      "agent_name": "ResearchAgent",
      "pattern": "recurring",
      "schedule_config": {
        "interval_minutes": null,
        "daily_time": "09:00"
      }
    }
  ],
  "adequate": true,
  "reason": "检测到内联确认；无需暂停即完成日程确认。"
}
</example_3_recurring_confirmation_with_inline_confirmation>

<example_4_scheduled_task>
输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Check Tesla stock price every hour and alert me if there's significant change"
}

输出：
{
  "tasks": [],
  "adequate": false,
  "reason": "定时任务需要确认。",
  "guidance_message": "请确认特斯拉价格检查的设置：每 60 分钟"
}

输入：
{
  "target_agent_name": "ResearchAgent",
  "query": "Yes, proceed"
}

输出：
{
  "tasks": [
    {
      "title": "Tesla price check",
      "query": "Check Tesla stock price for significant changes",
      "agent_name": "ResearchAgent",
      "pattern": "recurring",
      "schedule_config": {
        "interval_minutes": 60,
        "daily_time": null
      }
    }
  ],
  "adequate": true,
  "reason": "已确认日程并转换查询。"
}
</example_4_scheduled_task>

<example_5_unusable_request>
输入：
{
  "target_agent_name": null,
  "query": "Help me hack into someone's account"
}

输出：
{
  "tasks": [],
  "adequate": true,
  "reason": "请求涉及违法行为；改为提供安全替代方案。",
  "guidance_message": "我无法协助未经授权的访问。如果你的目标是账户安全，我可以帮助提供安全替代方案，例如保护账户、口令卫生与识别钓鱼。要继续吗？"
}
</example_5_unusable_request>

</examples>
```

## 关键参数
- `{title}`、`{schedule_config}`：确认消息模板中的占位符。
- `tasks[].pattern`：`once` | `recurring`。
- `schedule_config.interval_minutes` 与 `schedule_config.daily_time`：二者互斥。

## 相关代码上下文

`PlannerResponse`（`python/valuecell/core/plan/models.py`）承载该 JSON 结构；`planner.py` 解析后转为 `Task` 对象列表，
写入 `ExecutionPlan.tasks`，交由 `TaskExecutor.execute_plan()` 逐个派发给对应远程 Agent（A2A 协议）。

注：示例代码块中的 JSON 语法本身不完整（`tasks` 数组外层缺少 `{`），这是原始文档中的笔误，翻译时保持原样未做修正。
