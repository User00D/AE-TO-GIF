# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/core/plan/planner.py:389`（函数 `agentcard_to_prompt`）
- 变量名称: 无固定变量名，动态生成（`planner.py:357` 的 `tool_get_agent_description` 与 `planner.py:379` 的 `tool_get_enabled_agents` 均调用它）
- 功能模块: 核心编排层 — Agent 能力注入（把 Agent Card 转成 LLM 可读的提示词）
- 调用场景: 规划器在需要"选哪个 Agent"时，调用工具 `tool_get_enabled_agents()` / `tool_get_agent_description(name)`；返回值就是本函数拼接出的文本，被塞进规划器的工具返回结果中。

## 中文翻译

该函数是**模板化生成器**，而非静态提示词。它按以下结构拼接文本：

```text
# Agent: {card.name}

**Description:** {card.description}

## Available Skills

### 1. {skill.name} (`{skill.id}`)

**Description:** {skill.description}

**Examples:**
- {example_1}
- {example_2}
...

**Tags:** `{tag1}`, `{tag2}`, ...

---

### 2. {skill.name} (`{skill.id}`)
...（重复上述结构）
```

对应的字段语义（中文说明）：

- `# Agent: {card.name}`：Agent 的机器名（如 `ResearchAgent`、`NewsAgent`），规划器输出的 `agent_name` 必须与此一致。
- `**Description:**`：Agent 的整体定位描述。
- `## Available Skills`：该 Agent 的技能清单。
- `### {i}. {skill.name} (`{skill.id}`)`：技能名称与技能 ID。
- `**Description:**`：技能的具体能力说明（规划器靠它做语义匹配）。
- `**Examples:**`：示例查询，帮助规划器判断用户请求是否匹配该技能。
- `**Tags:**`：技能标签，用于补充语义线索（也是规划器判断"是否支持监控/提醒"等日程能力的依据）。

## 关键参数
- `card.name`、`card.description`、`card.skills[].name`、`card.skills[].id`、`card.skills[].description`、`card.skills[].examples`、`card.skills[].tags`。
- 数据来源：`python/configs/agent_cards/*.json`（如 `investment_research_agent.json`、`news_agent.json`、`prompt_strategy_agent.json`、`grid_agent.json`）。

## 相关代码上下文

```python
def tool_get_agent_description(self, agent_name: str) -> str:
    if card := self.agent_connections.get_agent_card(agent_name):
        if isinstance(card, AgentCard):
            return agentcard_to_prompt(card)
        if isinstance(card, dict):
            return str(card)
        return agentcard_to_prompt(card)
    return "The requested agent could not be found or is not available."

def tool_get_enabled_agents(self) -> str:
    map_agent_name_to_card = self.agent_connections.get_planable_agent_cards()
    parts = []
    for agent_name, card in map_agent_name_to_card.items():
        parts.append(f"<{agent_name}>")
        parts.append(agentcard_to_prompt(card))
        parts.append((f"</{agent_name}>\n"))
    return "\n".join(parts)
```

即：`tool_get_enabled_agents()` 会为每个可规划 Agent 生成一段 `agentcard_to_prompt` 结果，并用 `<{agent_name}> ... </{agent_name}>` 包裹。

**Agent Card 实例（节选，中文翻译）** — `python/configs/agent_cards/investment_research_agent.json`：

```text
# Agent: ResearchAgent
**Description:** 研究 Agent 分析 SEC 申报文件（10-K、10-Q、13F、8-K）与内部知识库，产出可溯源、可执行
的摘要与数据提取结果。它能提取财务科目、用知识库检索结果核对申报文件、总结 13F 持仓，并给出含具体工具调用
建议的后续步骤。

## Available Skills
### 1. 提取财务科目 (`extract_financials`)
**Description:** 检索并提取数值型财务科目（营收、净利润、EPS、现金流），并标注申报文件出处。
**Examples:**
- 苹果 2024 年 Q4 的营收是多少？请给出申报文件出处。
- 展示特斯拉最近一份 10-Q 的净利润与 EPS。
**Tags:** `10-K`, `10-Q`, `financials`, `filings`

### 2. 分析 13F 持仓 (`analyze_13f_filings`)
**Description:** 解析 13F 文件，提取机构持仓、头寸规模及其随时间的变化。
**Examples:**
- 伯克希尔·哈撒韦最新 13F 文件中的前几大持仓是什么？
- 先锋集团前十大持仓在过去四个季度如何变化？
**Tags:** `13F`, `holdings`, `institutional`

### 3. 综合上下文与评论 (`synthesize_context`)
**Description:** 将提取出的申报数据与知识库检索结果结合，提供解读、分析师评论与历史背景，并始终标注来源。
**Examples:**
- 总结分析师对苹果业绩指引的评论并注明来源。
- 对比公司 X 近三年的营收趋势并注明来源。
**Tags:** `analysis`, `context`, `knowledge-base`

### 4. 监控申报并通知 (`monitor_and_alert`)
**Description:** 追踪公司申报文件，并在出现相关的新 SEC 文件时通知用户，附简短、可溯源的摘要与建议的后续动作。
**Examples:**
- 特斯拉提交下一份 10-Q 时通知我，并给出一段带来源的摘要。
- 伯克希尔·哈撒韦 13F 持仓出现重大变化时提醒我。
**Tags:** `monitor`, `alerts`, `tracking`
```

> 说明：`skills[].tags` 中的 `monitor` / `alerts` / `tracking` 正是规划器判断"该 Agent 是否支持周期性监控任务"的依据（见 `PLANNER_INSTRUCTION` 的 2a 条）。

## 备注
- 该"动态提示词"是整个多 Agent 路由的核心：项目并没有把所有 Agent 的说明写死在系统提示词里，而是通过工具调用按需注入，从而支持 Agent 的热插拔。
- 已确认：`core/agent/connect.py:660` 的 `get_planable_agent_cards()` 会跳过 `ctx.planner_passthrough or ctx.hidden` 的 Agent。
  因此 `metadata.hidden=true` / `planner_passthrough=true` 的交易 Agent（`PromptBasedStrategyAgent`、`GridStrategyAgent`）**不会**出现在 `tool_get_enabled_agents()` 的候选列表中，它们主要由前端在创建策略时显式指定（即走 `target_agent_name` 直通路径）。
