# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/core/super_agent/prompts.py:57`
- 变量名称: `SUPER_AGENT_EXPECTED_OUTPUT`
- 功能模块: 核心编排层 / Super Agent 输出契约（含 few-shot 示例）
- 调用场景: 本应作为 `expected_output` 描述模型输出格式。**注意**：当前 `super_agent/core.py:69` 中该常量被注释掉，实际只使用 `output_schema=SuperAgentOutcome`（Pydantic 结构化输出），此常量作为文档/备用存在。

## 中文翻译

```text
<response_requirements>
只输出合法 JSON（不要 markdown、反引号或注释），并符合以下 schema：

{
    "decision": "answer" | "handoff_to_planner",
    "answer_content": "当 decision 为 'answer' 时的可选直接回答",
    "enriched_query": "可选，交给规划器的精炼复述",
    "reason": "决策的简短理由"
}

规则：
- 当 decision == "answer" 时：包含简短的 answer_content，省略 enriched_query。
- 当 decision == "handoff_to_planner" 时：优先包含能保留用户意图的 enriched_query。
- reason 保持简短、有帮助。
- answer_content 与 enriched_query 一律使用用户的语言生成。若无显式语言环境，则从用户查询中检测语言。
- 避免使用 "I can't"、"I cannot" 这类失败主义措辞；要么给出简洁的尽力回答，要么以清晰、自信的路由理由交接（例如"正在路由到规划器以选择最合适的专家 Agent"）。
- 确保 answer_content 只包含无需外部工具或检索即可产出的信息。若做不到，请选择 handoff_to_planner。
</response_requirements>

<examples>

<example_1_direct_answer>
输入：
{
    "query": "What is 2 + 2?"
}

输出：
{
    "decision": "answer",
    "answer_content": "4",
    "reason": "简单的事实性问题，可直接回答。"
}
</example_1_direct_answer>

<example_2_handoff_to_planner_specialist>
输入：
{
    "query": "Monitor Tesla SEC filings and alert me daily at 09:00 with a short summary."
}

输出：
{
    "decision": "handoff_to_planner",
    "enriched_query": "监控特斯拉（TSLA）的 SEC 申报文件，并提供每日 09:00 的简短摘要与提醒。",
    "reason": "路由到规划器，以选择最合适的专家监控 Agent。"
}
</example_2_handoff_to_planner_specialist>

<example_3_handoff_for_multi_step_analysis>
输入：
{
    "query": "Compare AAPL vs MSFT performance and valuation over the last quarter and recommend which looks better."
}

输出：
{
    "decision": "handoff_to_planner",
    "enriched_query": "比较苹果（AAPL）与微软（MSFT）上一季度的业绩与估值，并给出包含关键指标的简明建议。",
    "reason": "需要多步分析与工具；路由到规划器以调用合适的专业 Agent。"
}
</example_3_handoff_for_multi_step_analysis>

<example_4_handoff_schedule_confirmation>
输入：
{
    "query": "Confirm setting daily at 09:00 to monitor Tesla price and alert me"
}

输出：
{
    "decision": "handoff_to_planner",
    "enriched_query": "确认每日 09:00 监控特斯拉（TSLA）价格并发送提醒的日程设置",
    "reason": "将日程确认转发给规划器以管理周期性任务的创建。"
}
</example_4_handoff_schedule_confirmation>

</examples>
```

## 关键参数
- `decision`、`answer_content`、`enriched_query`、`reason`（均为模型动态生成）。

## 相关代码上下文

该常量与 `SUPER_AGENT_INSTRUCTION` 配套设计。当前实现（`super_agent/core.py:69`）改用 `output_schema=SuperAgentOutcome` 做强约束，
`expected_output` 被注释保留，因此模型输出契约主要由 Pydantic 模型 + instruction 共同保证。
