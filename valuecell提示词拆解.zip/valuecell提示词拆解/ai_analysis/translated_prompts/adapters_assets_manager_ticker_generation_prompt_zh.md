# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/adapters/assets/manager.py:381`（`system_prompt`）、`:386`（`user_prompt`）
- 变量名称: 函数内局部变量 `system_prompt` 与 `user_prompt`（位于 `_fallback_search_assets` 中）
- 功能模块: 工具适配层（Assets Adapter）— 资产搜索的 LLM 兜底逻辑
- 调用场景: 当用户在界面上搜索股票/加密货币，而各数据源适配器都返回空结果时，触发 `_fallback_search_assets()`：
  让 LLM 根据用户查询"猜"出可能的标准化 ticker ID，再逐个验证是否真实存在。

## 中文翻译

### 系统提示词

```text
你是一名金融数据专家，负责把搜索查询映射到标准化的 ticker 格式。始终只返回合法的 JSON 数组。
```

### 用户提示词

```text
给定用户搜索查询："{query.query}"

生成一组可能匹配该查询的内部 ticker ID 列表。内部 ticker 格式为：EXCHANGE:SYMBOL

支持的交易所及其格式：
- NASDAQ: NASDAQ:SYMBOL（例如 NASDAQ:AAPL、NASDAQ:MSFT）
- NYSE: NYSE:SYMBOL（例如 NYSE:JPM、NYSE:BAC）
- AMEX: AMEX:SYMBOL（例如 AMEX:GORO、AMEX:GLD）
- SSE: SSE:SYMBOL（上海证券交易所，6 位代码，例如 SSE:601398、SSE:510050）
- SZSE: SZSE:SYMBOL（深圳证券交易所，6 位代码，例如 SZSE:000001、SZSE:002594、SZSE:300750）
- BSE: BSE:SYMBOL（北京证券交易所，6 位代码，例如 BSE:835368、BSE:560800）
- HKEX: HKEX:SYMBOL（香港交易所，5 位代码并带前导零，例如 HKEX:00700、HKEX:03033）
- CRYPTO: CRYPTO:SYMBOL（例如 CRYPTO:BTC、CRYPTO:ETH）

需要考虑：
1. 常见股票代码与公司名称
2. 中文公司名（如果查询包含中文字符）
3. 加密货币名称
4. 指数名称
5. ETF 名称

只返回一个 ticker 字符串的 JSON 数组，例如：
["NASDAQ:AAPL", "NYSE:AAPL", "HKEX:00700"]

生成至少 1 个、最多 10 个可能的 ticker 候选。要有创意但要现实。
```

## 关键参数
- `{query.query}`：用户输入的搜索词（`AssetSearchQuery.query`）。
- 支持的交易所前缀：`NASDAQ`、`NYSE`、`AMEX`、`SSE`、`SZSE`、`BSE`、`HKEX`、`CRYPTO`。

## 相关代码上下文

```python
model = get_model("PRODUCT_MODEL_ID")

system_prompt = (
    "You are a financial data expert that helps map search queries to "
    "standardized ticker formats. Always respond with valid JSON arrays only."
)
user_prompt = f"""Given the user search query: "{query.query}" ..."""

agent = Agent(model=model, instructions=[system_prompt], markdown=False)
response = agent.run(user_prompt)
response_text = response.content.strip()
# 兼容 LLM 可能用 markdown 包裹的 JSON
if response_text.startswith("```json"):
    response_text = response_text.split("```json")[1].split("```")[0].strip()
elif response_text.startswith("```"):
    response_text = response_text.split("```")[1].split("```")[0].strip()

possible_tickers = json.loads(response_text)
# 逐个校验：必须含 ":"、必须能匹配适配器、必须能取到资产信息
```

三个值得注意的工程细节：

1. **这是纯粹的兜底路径**：只有当常规适配器搜索返回空结果时才触发，因此 LLM "编造"的风险被限制在最小范围。
2. **LLM 的输出必须经过验证**：生成的 ticker 会逐个通过 `get_adapter_for_ticker()` 与 `get_asset_info()` 校验，不存在的候选会被直接丢弃。
3. **做了解析容错**：代码显式处理了 LLM 用三反引号 `json` 或三反引号包裹输出 JSON 的情况——这是对"未使用结构化输出模式"的补偿性处理。
