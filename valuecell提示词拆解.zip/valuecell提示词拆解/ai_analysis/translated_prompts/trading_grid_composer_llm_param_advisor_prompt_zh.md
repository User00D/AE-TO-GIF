# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/agents/common/trading/decision/grid_composer/llm_param_advisor.py:17`（`SYSTEM_PROMPT`）；动态指令在 `:160`
- 变量名称: 模块级常量 `SYSTEM_PROMPT`（注意：与 `prompt_based/system_prompt.py` 中的同名常量是不同的变量）；函数内局部变量 `instructions`
- 功能模块: 交易 Agent — 网格策略的动态参数顾问（GridParamAdvisor）
- 调用场景: 当网格策略开启 `use_llm_params=True` 时，`GridComposer` 每 300 秒（`_llm_advice_refresh_sec`）或市场变化超过阈值时调用一次 `advise(context)`，让 LLM 动态推荐网格参数（步长、最大步数、基础仓位比例等），而不是写死。

## 中文翻译

### 1) 系统提示词（`llm_param_advisor.py:17`）

```text
你是一个网格参数顾问。
在给定当前市场快照指标与运行时设置的情况下，动态提出网格参数建议。
对于高流动性、高波动性的交易对，使用更高的敏感度（更小的 step_pct、更大的 max_steps）；否则使用更低的敏感度。
遵守典型取值范围：step_pct 0.0005~0.01、max_steps 1~5、base_fraction 0.03~0.10。
在合适时，可选地包含网格区间边界（grid_lower_pct、grid_upper_pct）与 grid_count。
依据组合上下文来校准 base_fraction 与可选的 grid_count：equity、buying_power、free_cash 以及 constraints.max_leverage。
让参数敏感度与可用资金和风险限额（cap_factor）保持一致。资金紧张时，倾向更小的 base_fraction 与更少的步数。
输出纯 JSON，字段包括：grid_step_pct、grid_max_steps、grid_base_fraction，可选包含 grid_lower_pct、grid_upper_pct、grid_count、advisor_rationale。
advisor_rationale 应简要说明你选择参数的思路与操作依据（例如波动率、流动性、资金费率、持仓量 OI、购买力）。
```

### 2) 每轮追加的动态指令（`llm_param_advisor.py:160`）

```text
只返回 JSON。包含 advisor_rationale，概述你的思考过程与操作依据。
保持在取值范围内；对于高流动性与高波动性的交易对，倾向更小的 step_pct。
如果 funding.rate 偏高或 open_interest 较大，倾向更紧的网格与更小的 base_fraction；否则保持保守。
考虑 portfolio.equity、buying_power、free_cash、constraints.max_leverage 与 cap_factor 来缩放 base_fraction 与可选的 grid_count。
避免建议在可用购买力下会隐含过大总仓位的参数组合。
当提供了 previous_params 时，以它为锚；倾向渐进式调整（例如 grid_count 变化控制在 ±2 以内、step_pct 保持小幅变化），
除非市场指标表明出现了明显的状态切换。
```

### 3) 随指令拼接的上下文（JSON）

```text

Context:
{
  "market_type": "<SPOT | 衍生品等>",
  "decide_interval": <决策间隔>,
  "symbols": ["..."],
  "snapshot_metrics": {
    "<SYMBOL>": {
      "price.last": 0.0,
      "price.change_pct": 0.0,
      "price.volume": 0.0,
      "open_interest": 0.0,
      "funding.rate": 0.0
    }
  },
  "previous_params": { "grid_step_pct": 0.0, "grid_max_steps": 0, "grid_base_fraction": 0.0, "...": "..." },
  "portfolio": {
    "equity": 0.0,
    "buying_power": 0.0,
    "free_cash": 0.0,
    "constraints": { "max_leverage": 0.0, "quantity_step": 0.0, "min_trade_qty": 0.0,
                     "max_order_qty": 0.0, "max_position_qty": 0.0 },
    "cap_factor": 0.0
  }
}
```

（`previous_params` 与 `portfolio` 为可选，组装失败时会被跳过的可选上下文。）

## 关键参数
- 输出字段：`grid_step_pct`（0.0005~0.01）、`grid_max_steps`（1~5）、`grid_base_fraction`（0.03~0.10）、
  可选 `grid_lower_pct`、`grid_upper_pct`、`grid_count`、`advisor_rationale`。
- 输入字段：`snapshot_metrics`（价格/持仓量/资金费率）、`previous_params`（上一轮已采纳参数）、`portfolio`（基金/购买力/约束/cap_factor）。
- 结构化输出模型：`GridParamAdvice`（pydantic）。

## 相关代码上下文

```python
agent = AgnoAgent(
    model=model,
    output_schema=GridParamAdvice,
    markdown=False,
    instructions=[SYSTEM_PROMPT],
    use_json_mode=model_utils.model_should_use_json_mode(model),
)
response = await agent.arun(prompt)
```

该顾问体现了一种"LLM 作为参数调优器（LLM-as-a-Tuner）"的嵌入模式：
LLM 不直接决定买卖动作，而是输出一组结构化参数，交由**确定性规则引擎**（`GridComposer`）执行规则化网格交易。
这样既保留了 LLM 对市场状态的适应能力，又让实际下单逻辑完全可解释、可回测。
若 LLM 调用失败或输出校验不通过，`advise()` 返回 `None`，网格策略回退到默认参数，保证系统可用性。
