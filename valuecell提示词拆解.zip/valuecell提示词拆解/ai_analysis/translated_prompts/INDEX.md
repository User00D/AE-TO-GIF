# 提示词索引（ValueCell）

本目录收录 ValueCell 项目中所有可识别的提示词（Prompt / Instruction / Expected Output / Agent Card）的中文翻译文档。
原始提示词全部为英文（无中文原文），因此均提供完整翻译。

| 序号 | 提示词名称 | 所属模块 | 中文文档 | 原始位置 |
|------|-----------|----------|----------|----------|
| 1 | `SUPER_AGENT_INSTRUCTION` | 核心编排 / 前台分诊 | [文档](./core_super_agent_prompts_super_agent_triage_prompt_zh.md) | `python/valuecell/core/super_agent/prompts.py:10` |
| 2 | `SUPER_AGENT_EXPECTED_OUTPUT` | 核心编排 / 前台分诊输出契约 | [文档](./core_super_agent_prompts_super_agent_expected_output_prompt_zh.md) | `python/valuecell/core/super_agent/prompts.py:57` |
| 3 | `PLANNER_INSTRUCTION` | 核心编排 / 任务规划器 | [文档](./core_plan_prompts_planner_instruction_prompt_zh.md) | `python/valuecell/core/plan/prompts.py:10` |
| 4 | `PLANNER_EXPECTED_OUTPUT` | 核心编排 / 规划器输出契约 | [文档](./core_plan_prompts_planner_expected_output_prompt_zh.md) | `python/valuecell/core/plan/prompts.py:77` |
| 5 | `agentcard_to_prompt`（动态生成） | 核心编排 / Agent 能力注入 | [文档](./core_plan_planner_agentcard_to_prompt_zh.md) | `python/valuecell/core/plan/planner.py:389` |
| 6 | `KNOWLEDGE_AGENT_INSTRUCTION` | 研究 Agent / 系统提示词 | [文档](./agents_research_agent_prompts_knowledge_agent_instruction_prompt_zh.md) | `python/valuecell/agents/research_agent/prompts.py:1` |
| 7 | `KNOWLEDGE_AGENT_EXPECTED_OUTPUT` | 研究 Agent / 输出契约 | [文档](./agents_research_agent_prompts_knowledge_agent_expected_output_prompt_zh.md) | `python/valuecell/agents/research_agent/prompts.py:88` |
| 8 | `NEWS_AGENT_INSTRUCTIONS` | 新闻 Agent / 系统提示词 | [文档](./agents_news_agent_prompts_news_agent_instructions_prompt_zh.md) | `python/valuecell/agents/news_agent/prompts.py:3` |
| 9 | `SYSTEM_PROMPT`（交易规划器） | 交易 Agent / LLM 决策系统提示词 | [文档](./trading_decision_prompt_based_system_prompt_zh.md) | `python/valuecell/agents/common/trading/decision/prompt_based/system_prompt.py:11` |
| 10 | `_build_llm_prompt`（动态生成） | 交易 Agent / 每轮上下文构造 | [文档](./trading_decision_prompt_based_composer_build_llm_prompt_zh.md) | `python/valuecell/agents/common/trading/decision/prompt_based/composer.py:138` |
| 11 | `SYSTEM_PROMPT`（网格参数顾问） | 交易 Agent / 网格参数自优化 | [文档](./trading_grid_composer_llm_param_advisor_prompt_zh.md) | `python/valuecell/agents/common/trading/decision/grid_composer/llm_param_advisor.py:17` |
| 12 | `default.txt`（默认策略模板） | 交易 Agent / 用户策略模板 | [文档](./prompt_strategy_agent_templates_default_prompt_zh.md) | `python/valuecell/agents/prompt_strategy_agent/templates/default.txt:1` |
| 13 | `aggressive.txt`（激进策略模板） | 交易 Agent / 用户策略模板 | [文档](./prompt_strategy_agent_templates_aggressive_prompt_zh.md) | `python/valuecell/agents/prompt_strategy_agent/templates/aggressive.txt:1` |
| 14 | `insane.txt`（极端激进策略模板） | 交易 Agent / 用户策略模板 | [文档](./prompt_strategy_agent_templates_insane_prompt_zh.md) | `python/valuecell/agents/prompt_strategy_agent/templates/insane.txt:1` |
| 15 | Ticker 生成提示词（system + user） | 工具适配层 / 资产搜索回退 | [文档](./adapters_assets_manager_ticker_generation_prompt_zh.md) | `python/valuecell/adapters/assets/manager.py:381` |

## 说明

- 除上表外，项目还存在一类"隐式提示词"：`python/configs/agent_cards/*.json` 中的 Agent Card（`description` / `skills` / `examples` / `tags`）。
  它们不直接作为 `instructions` 传入，而是由 `agentcard_to_prompt()` 动态拼接后注入规划器上下文，本质上等价于"候选 Agent 的说明书"。详见分析报告第 5 节。
- 交易类提示词存在"两层"结构：
  1. 系统层（`system_prompt.py`）定义角色与 IO 契约；
  2. 用户策略层（`templates/*.txt` 或前端自定义）定义交易风格，两者在 `_build_prompt_text()` 中融合。
