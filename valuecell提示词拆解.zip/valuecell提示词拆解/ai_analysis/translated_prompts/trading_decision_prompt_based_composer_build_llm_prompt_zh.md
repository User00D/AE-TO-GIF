# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/agents/common/trading/decision/prompt_based/composer.py:138`（函数 `_build_llm_prompt`，其中固定指令在 `:185`）
- 变量名称: 函数内局部变量 `instructions`（固定指令）+ `payload`（动态上下文）；同时相关的是 `_build_prompt_text`（`:73`）负责融合用户策略文本
- 功能模块: 交易 Agent — 每个决策周期的用户消息构造（上下文工程的核心）
- 调用场景: 每个 `decide_interval` 周期调用一次 `compose(context)` → `_build_llm_prompt(context)`，结果作为**用户消息**送进带 `SYSTEM_PROMPT` 的 LLM。

## 中文翻译

### 1) 固定指令段（`composer.py:185`）

```text
阅读 Context 并做出决定。
features.1m = 结构性趋势（240 个周期），features.1s = 实时信号（180 个周期）。
market.funding_rate：为正表示多头向空头付费。
遵守 constraints 与 risk_flags。当优势不明确时优先 NOOP。
始终包含一段简洁的顶层 'rationale'。
如果你选择 NOOP（items 为空），把 'rationale' 设为解释原因：结合当前价格与 'price.change_pct'
相对阈值的情况，以及导致 NOOP 的任何约束或风险标记。
输出带 items 数组的 JSON。
```

### 2) 随指令拼接的动态上下文（JSON）

```text

Context:
{payload 的 JSON 序列化结果（ensure_ascii=False）}
```

`payload` 的字段结构（由 `_build_llm_prompt` 组装，`prune_none` 会剔除空值）：

```json
{
  "strategy_prompt": "<用户策略文本：custom_prompt 与/或 prompt_text 的融合结果>",
  "summary": {
    "active_positions": 0,
    "total_value": 0.0,
    "account_balance": 0.0,
    "free_cash": 0.0,
    "unrealized_pnl": 0.0,
    "sharpe_ratio": 0.0
  },
  "market":      "<由市场快照特征压缩得到的行情摘要：价格/OI/资金费率等>",
  "features":    "<按时间粒度分组的技术特征：features.1m 与 features.1s>",
  "positions":   [ { "symbol": "", "qty": 0.0, "unrealized_pnl": 0.0, "entry_ts": 0 } ],
  "constraints": { "max_positions": 0, "max_leverage": 0.0, "...": "..." }
}
```

### 3) 用户策略文本的融合逻辑（`_build_prompt_text`, `composer.py:73`）

```text
如果同时存在 custom_prompt 与 prompt_text：返回 "{custom_prompt}\n\n{prompt_text}"。
如果只有 custom_prompt：返回 custom_prompt。
如果只有 prompt_text：返回 prompt_text。
兜底：返回 "Compose trading instructions for symbols: {symbols}。"（symbols 以逗号连接）。
```

## 关键参数
- `strategy_prompt`：来自用户策略配置（`trading_config.custom_prompt` 优先，其次 `trading_config.prompt_text`）。
- `summary.*`：组合摘要（`_build_summary` 组装，见 `composer.py:121`）。
- `features`：由 `group_features(context.features)` 按粒度分组，`1m` 为结构性趋势、`1s` 为实时信号。
- `market`：由 `extract_market_section(features["market_snapshot"])` 压缩。
- `positions`：仅包含数量非零的持仓，且携带 `entry_ts` 以支持提示词中的"避免短期反复交易"规则。
- `constraints`：来自 `pv.constraints.model_dump(mode="json", exclude_none=True)`。

## 相关代码上下文

```python
instructions = (
    "Read Context and decide. "
    "features.1m = structural trends (240 periods), features.1s = realtime signals (180 periods). "
    "market.funding_rate: positive = longs pay shorts. "
    "Respect constraints and risk_flags. Prefer NOOP when edge unclear. "
    "Always include a concise top-level 'rationale'. "
    "If you choose NOOP (items is empty), set 'rationale' to explain why: reference current prices and "
    "'price.change_pct' vs thresholds, and any constraints or risk flags that led to NOOP. "
    "Output JSON with items array."
)
return f"{instructions}\n\nContext:\n{json.dumps(payload, ensure_ascii=False)}"
```

**上下文工程要点（重要）**：这段"用户消息"不是自然语言提问，而是**把决策所需的全部状态序列化成一个 JSON 上下文**——
包含策略意图（`strategy_prompt`）、账户状态（`summary`/`positions`）、市场状态（`market`/`features`）、以及行动边界（`constraints`）。
系统提示词定义"如何思考"，本函数定义"看到什么"，两者共同构成交易 Agent 的每轮 prompt。

由于 `sharpe_ratio` 被放进 `summary`，模型可以在每个周期根据上一份提示词中的绩效反馈自适应调整交易频率与规模，
形成"决策 → 执行 → 记录历史 → 计算夏普 → 下一轮决策"的闭环。
