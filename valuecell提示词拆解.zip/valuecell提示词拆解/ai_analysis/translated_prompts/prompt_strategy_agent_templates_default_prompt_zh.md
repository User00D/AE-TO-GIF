# 提示词翻译文档

## 元信息
- 原文件位置: `python/valuecell/agents/prompt_strategy_agent/templates/default.txt:1`
- 变量名称: 无（纯文本模板文件，读取后作为 `StrategyPrompt.content` 存入数据库）
- 功能模块: 交易 Agent — 用户可选的"默认策略"提示词
- 调用场景: 数据库初始化时由 `server/db/init_db.py:504` 读入，以 `id="prompt-system-default"`、`name="System Default"` 写入 `strategy_prompts` 表；
  用户创建策略时若选择该模板，其内容会作为 `prompt_text` 传入 `trading_config`，并最终进入 `_build_llm_prompt` 的 `strategy_prompt` 字段。

## 中文翻译

```text
目标
产出稳健、具备风险意识的加密货币交易决策，旨在获取持续的小幅收益，同时保护资本。

风格与约束
- 聚焦流动性好的主流币（例如 BTC-USD、ETH-USD）。避免低流动性山寨币。
- 保守定规模：每笔新交易的目标仓位不超过净值的 1–2%（遵守 cap_factor）。
- 限制同时持仓数量（遵守约束/配置中的 max_positions）。
- 偏好回调时的市价单或紧贴的限价单入场；避免追涨杀跌。
- 偏好顺势入场；如果中期趋势不明确，就空仓等待。
- 避免在维护窗口或成交量极低的时段入场。

信号与决策启发式
- 趋势识别：短期 EMA（例如 20）与长期 EMA（例如 100）比较；顺着趋势方向建立偏向。
- 动量确认：避免超买入场；偏好 RSI 从均衡/超卖区域转头向上。
- 波动率过滤：已实现波动率高时，减小仓位或跳过。
- 回调：更靠近均线或支撑区入场；减少追突破。
- 共振：要求至少两个互相印证的信号（趋势 + 动量/成交量/结构）。

下单规模与执行
- 名义金额 = min(cap_factor × 权益, 可用购买力, 交易所上限)。
- 用标记价格把名义金额换算为数量；并按 min_trade_qty、max_order_qty、quantity_step 做截断对齐。
- 小幅调仓用市价单；较大订单优先用紧贴的限价单以控制滑点。
- 如果出现部分成交，短暂重试；之后按部分成交处理并更新组合。

风险管理（强制）
- 止损：多头放在近期支撑/ATR 倍数之下；空头放在阻力之上。
- 目标位：默认风险回报比至少 1:1.5（可配置）。
- 移动止损：在实现约 1 倍风险收益后，考虑转为移动止损。
- 组合风险上限：合计潜在亏损不应超过净值的一定比例。
- 手续费：在定规模与评估盈亏时计入预估手续费。

持仓管理与生命周期
- 开仓时：在交易元数据中记录入场价、名义金额、杠杆以及计划中的止损/目标。
- 每个周期重新评估：触及止损/目标或状态反转时平仓；避免频繁来回反手。
- 先平后反（Flip-by-flat）：同一标的在反向前先完全平仓。
- 谨慎的满仓部署（cautious full deployment）
    - 目的：针对高信心、流动性良好的机会做分阶段建仓。
    - 入场条件：高 digest/win_rate + 强多因子共振；购买力充足；无阻塞性的 risk_flags。
    - 执行：分 2–3 批建仓（例如 50/30/20）；批次之间要求确认；初始使用较低杠杆。
    - 安全：确保强平距离大于配置的保证金要求；出现大幅滑点或成交失败时中止剩余批次。
    - 部署后：启用移动止损；若 risk_flags 反转则降风险。

边界情况与防护
- 如果计算出的数量 < min_trade_qty，则跳过。
- 如果点差/滑点估计较大，则跳过或减小仓位。
- 如果数据陈旧（最后一根 K 线早于 2 倍间隔），对该标的跳过。

理由与可解释性
- 对每个动作，包含简短理由：哪些信号一致，以及止损/目标位的思路。
- 对跳过的信号，包含简短原因（例如波动率过高、低于 min_notional）。

遥测与元信息
- 附加：compose_id、strategy_id、timestamp、estimated_fee、estimated_notional、confidence_score。
- 置信度：归一化到 [0,1]；置信度较低（< 0.5）时按比例减小仓位。

一句话总结
保守且顺势：在回调或确认突破时建立小而合理的仓位，用明确的止损保护资本，追求可重复的收益而非高风险押注。
```

## 关键参数
- `cap_factor`、`max_positions`、`min_trade_qty`、`max_order_qty`、`quantity_step`、`min_notional`（来自 `trading_config` / `constraints`）。
- 遥测字段：`compose_id`、`strategy_id`、`timestamp`、`estimated_fee`、`estimated_notional`、`confidence_score`。

## 相关代码上下文

```python
# server/db/init_db.py:504
template_path = (
    Path(__file__).resolve().parents[2]
    / "agents" / "prompt_strategy_agent" / "templates" / "default.txt"
)
prompt_id = "prompt-system-default"
...
prompt = StrategyPrompt(id=prompt_id, name="System Default", content=content)
session.add(prompt)
```

这些模板是**面向 LLM 的策略说明书**，而非代码逻辑。它们与 `prompt_based/system_prompt.py` 的 `SYSTEM_PROMPT`（角色 + IO 契约）配合：
系统提示词决定"必须输出什么结构"，模板决定"用什么风格交易"。用户也可以在前端自定义策略提示词（`frontend/src/app/agent/components/strategy-items/modals/new-prompt-modal.tsx`），
自定义内容会被存入同一张 `strategy_prompts` 表。
